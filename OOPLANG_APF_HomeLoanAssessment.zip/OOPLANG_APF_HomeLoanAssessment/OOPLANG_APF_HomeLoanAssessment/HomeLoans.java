public class HomeLoans {
    public static AssessType singleHead1, singleHead2, singleHead3, singleHead4, singleHead5, singleHead6, singleHead7;
    public static Home vacantLot, houseNLot, residential, townHouse, construction, homeImprovement, apartment;
    
    public static void initHomeLoans() {
        initHomes();
    }

    public static void initHomes() {
    
        // Assessment Type: Vacant Lot
        AssessType[] loanType1 = {singleHead1};
        vacantLot = new Home("Home Loan Plan: Vacant Lot", loanType1);
        
        // Assessment Type: House and Lot
        AssessType[] loanType2 = {singleHead2};
        houseNLot = new Home("Home Loan Plan: House and Lot", loanType2);

        // Assessment Type: Town House
        AssessType[] loanType3 = {singleHead3};
        townHouse = new Home("Home Loan Plan: Town House", loanType3);
       
        // Assessment Type: Residential
        AssessType[] loanType4 = {singleHead4};
        residential = new Home("Home Loan Plan: Residential", loanType4);
       
        // Assessment Type: Construction
        AssessType[] loanType5 = {singleHead5};
        construction = new Home("Home Loan Plan: Construction", loanType5);
       
        // Assessment Type:  Home Improvement
        AssessType[] loanType6 = {singleHead6};
        homeImprovement = new Home("Home Loan Plan: Home Improvement", loanType6);
        
        // Assessment Type: Apartment
        AssessType[] loanType7 = {singleHead7};
        apartment = new Home("Home Loan Plan: Apartment", loanType7);
    }
    
    public static Home[] getHomes() {
        Home[] homes = {vacantLot, houseNLot, residential, townHouse, construction, homeImprovement, apartment};
        return homes;
    }
}
