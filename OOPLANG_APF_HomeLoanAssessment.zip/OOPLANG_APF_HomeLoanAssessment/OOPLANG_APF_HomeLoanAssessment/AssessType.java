public class AssessType {
    private String label;
    private double price;

    public String getLabel() {
        return this.label;
    }
    
    public void setLabel(String label) {
        this.label = label;
    }
}
