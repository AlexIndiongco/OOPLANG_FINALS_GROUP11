import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MainFrame extends JFrame {
    // Menu Panel
    // Menu: Panel attributes
    private JPanel menuPanel = new JPanel(new GridBagLayout());
    private Color color = new Color(171,219,227);

    // Menu: Title Label
    private JLabel titleLabel = new JLabel();
    private JLabel infoLabel = new JLabel();

    // Menu: Home Loan Buttons
    private JButton vacantLotButton = new JButton();
    private JButton houseNLotButton = new JButton();
    private JButton residentialCondoButton = new JButton();
    private JButton townHouseButton = new JButton();
    private JButton constructionButton = new JButton();
    private JButton homeImprovementButton = new JButton();
    private JButton apartmentButton = new JButton();
    private Font homeLoanNameFont = new Font("Cambria", Font.PLAIN, 16);

    // Menu: Home Loan Objects
    private Home vacantLot, houseNLot, residential, townHouse, construction, homeImprovement, apartment, selectedLoan;

    
    // Assessment Panel
    // Information: Panel
    private JPanel AssessmentPanel = new JPanel(new GridBagLayout());

    // Assessment Panel - Information: Title Label
    private JButton backButton = new JButton();
    private JButton confirmButton = new JButton();
    private JButton clearButton = new JButton();

    // Assessment Panel - Information
    private JLabel homeLoanNameLabel = new JLabel();  

    // Assessment Panel - Information: Assessment Labels
    private JLabel nameLabel = new JLabel();
    private JLabel addressLabel = new JLabel();
    private JLabel employmentLabel= new JLabel();
    private JLabel propertySPLabel = new JLabel();
    private JLabel downPaymentLabel = new JLabel();
    private JLabel proposedCollateralLabel = new JLabel();
    private JLabel monthsPayLabel = new JLabel();

    // Assessment Panel - Information: TextFields
    private JTextField nameTextField = new JTextField();
    private JTextField addressTextField = new JTextField();
    private JTextField propertySPTextField = new JTextField();
    private JTextField downPayTextField = new JTextField();
    private JTextField monthsPayTextField = new JTextField();

    // Assessment Panel - Information: Combo Box
    private JComboBox employmentComboBox;
    private JComboBox proposedCollateralComboBox;
    private JComboBox downPaymentComboBox;
    
    // Assessment Panel - Billing Area
    private JLabel billingLabel = new JLabel();
    private JTextArea billTextArea = new JTextArea();

    public MainFrame() {
        initHomes();
        initMenuPanel();
        initAssessmentPanel();
        initFrames();
    }
    
    public void initFrames() { 
        addWindowListener(new WindowAdapter() {
                public void windowClosing(WindowEvent e) {
                    exitForm(e);
                }
            });

        setTitle("APF | HOME LOAN ASSESSMENT");
        setContentPane(menuPanel);
        setResizable(false);
        pack();
    }

    // Assessment Type
    private void initHomes() { 
        HomeLoans.initHomeLoans();
        Home[] homes = HomeLoans.getHomes();

        vacantLot = homes[0];
        houseNLot = homes[1];
        townHouse = homes[2];
        residential = homes[3];
        construction = homes[4];
        homeImprovement = homes[5];
        apartment = homes[6];

    }

    // Main Menu ===============================================================================
    public void initMenuPanel() {
        GridBagConstraints gridConstraints = new GridBagConstraints();
        gridConstraints.anchor = gridConstraints.CENTER; 
        gridConstraints.insets = new Insets(20,20,0,20);
        
        // Main Menu: HOME LOAN ASSESSEMENT Label
        titleLabel.setText("HOME LOAN ASSESSMENT");
        titleLabel.setFont(new Font("Cambria", Font.PLAIN, 40));
        gridConstraints.gridwidth = 5;
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        menuPanel.setBackground(color);
        menuPanel.add(titleLabel, gridConstraints);
        
        // Main Menu: Information Label
        infoLabel.setText("Choose one (1) Home Loan Plans to continue.");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 1;
        menuPanel.add(infoLabel, gridConstraints);

        
        // Main Menu: Size 
        gridConstraints.ipadx = 20;
        gridConstraints.ipady = 40;

        // Main Menu: Buttons
        // Main Menu: Vacant Lot Button
        vacantLotButton.setFont(homeLoanNameFont);
        vacantLotButton.setText("Vacant Lot");
        gridConstraints.gridwidth = 1;
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 2;
        vacantLotButton.setPreferredSize(new Dimension(160, 50));
        gridConstraints.insets.set(30,40,0,0);
        menuPanel.add(vacantLotButton, gridConstraints);

        vacantLotButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    vacantLotButtonActionPerformed(e);
                }
            });

            
        // Main Menu: House and Lot Button 
        houseNLotButton.setFont(homeLoanNameFont);
        houseNLotButton.setText("House and Lot");
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 2;
        houseNLotButton.setPreferredSize(new Dimension(160, 50));
        gridConstraints.insets.set(30,40,0,0);
        menuPanel.add(houseNLotButton , gridConstraints);

        houseNLotButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    houseNLotButtonActionPerformed(e);
                }
            });

            
        // Main Menu: Residential Button
        residentialCondoButton.setFont(homeLoanNameFont);
        residentialCondoButton.setText("Residential Condo");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 3;
        residentialCondoButton.setPreferredSize(new Dimension(160, 50));
        gridConstraints.insets.set(30,40,0,0);
        menuPanel.add(residentialCondoButton, gridConstraints);

        residentialCondoButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    residentialCondoButtonActionPerformed(e);
                }
            });

            
        // Main Menu: TownHouse Button
        townHouseButton.setFont(homeLoanNameFont);
        townHouseButton.setText("Town House");
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 3;
        townHouseButton.setPreferredSize(new Dimension(160, 50));
        gridConstraints.insets.set(30,40,0,0);
        menuPanel.add(townHouseButton, gridConstraints);

        townHouseButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    townHouseButtonActionPerformed(e);
                }
            });

            
        // Main Menu: Construction Button
        constructionButton.setFont(homeLoanNameFont);
        constructionButton.setText("Construction");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 4;
        constructionButton.setPreferredSize(new Dimension(160, 50));
        gridConstraints.insets.set(30,40,0,0);
        menuPanel.add(constructionButton, gridConstraints);

        constructionButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    constructionButtonActionPerformed(e);
                }
            });

            
        // Main Menu: Home Improvement Button
        homeImprovementButton.setFont(homeLoanNameFont);
        homeImprovementButton.setText("Home Improvement");
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 4;
        homeImprovementButton.setPreferredSize(new Dimension(160, 50));
        gridConstraints.insets.set(30,40,0,0);
        menuPanel.add(homeImprovementButton, gridConstraints);

        homeImprovementButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    homeImprovementButtonActionPerformed(e);
                }
            });

            
        // Main Menu: Apartment Button
        apartmentButton.setFont(homeLoanNameFont);
        apartmentButton.setText("Apartment");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 5;
        apartmentButton.setPreferredSize(new Dimension(160, 50));
        gridConstraints.insets.set(30,40,40,0);
        menuPanel.add(apartmentButton, gridConstraints);

        apartmentButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    apartmentButtonActionPerformed(e);
                }
            });
    }

    
    // Assessement Panel ===============================================================================
    private void initAssessmentPanel() {
        GridBagConstraints gridConstraints = new GridBagConstraints();
        gridConstraints.anchor = GridBagConstraints.WEST;
        gridConstraints.insets.set(10, 10, 5, 5);
        AssessmentPanel.setBackground(color);
        
        
        // Assessement Panel (LABEL)
        // Assessement Panel: Name
        nameLabel.setFont(homeLoanNameFont);
        nameLabel.setText("Full Name: ");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 1;
        AssessmentPanel.add(nameLabel, gridConstraints);
        
        // Assessement Panel: Address
        addressLabel.setFont(homeLoanNameFont);
        addressLabel.setText("Address: ");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 2;
        AssessmentPanel.add(addressLabel, gridConstraints);
        
        // Assessement Panel:Employment
        employmentLabel.setFont(homeLoanNameFont);
        employmentLabel.setText("Employment: ");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 3;
        AssessmentPanel.add(employmentLabel, gridConstraints);

        // Assessement Panel: Property Selling Price
        propertySPLabel.setFont(homeLoanNameFont);
        propertySPLabel.setText("Property Selling Price: ");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 4;
        AssessmentPanel.add(propertySPLabel, gridConstraints);

        // Assessement Panel: Downpayment
        downPaymentLabel.setFont(homeLoanNameFont);
        downPaymentLabel.setText("Downpayment: ");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 6;
        AssessmentPanel.add(downPaymentLabel, gridConstraints);

        // Assessement Panel: Propose Collateral
        proposedCollateralLabel.setFont(homeLoanNameFont);
        proposedCollateralLabel.setText("Proposed Collateral: ");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 8;
        AssessmentPanel.add(proposedCollateralLabel, gridConstraints);

        // Assessement Panel: Months to Pay
        monthsPayLabel.setFont(homeLoanNameFont);
        monthsPayLabel.setText("Months to Pay: ");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 9;
        AssessmentPanel.add(monthsPayLabel, gridConstraints);

        
        
        // Assessement Panel (TEXTFIELDS)
        // Assessement Panel: Name
        nameTextField.setText("");
        nameTextField.setColumns(15);
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 1;    
        AssessmentPanel.add(nameTextField, gridConstraints);
        
        // Assessement Panel: Address
        addressTextField.setText("");
        addressTextField.setColumns(15);
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 2;    
        AssessmentPanel.add(addressTextField, gridConstraints);

        // Assessement Panel: Employment
        employmentComboBox = new JComboBox(new Object[] {"-----", "Locally-Employed", "Self-Employed", "OFW"});
        employmentComboBox.setEditable(false);
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 3; 
        AssessmentPanel.add(employmentComboBox, gridConstraints);

        employmentComboBox.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    employmentComboBoxActionPerformed(e);

                }
            });
        
        // Assessement Panel: Property Selling Price
        propertySPTextField.setText("");
        propertySPTextField.setColumns(15);
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 4;    
        AssessmentPanel.add(propertySPTextField, gridConstraints);
        
        propertySPTextField.addKeyListener(new KeyAdapter() {
        public void keyTyped(KeyEvent e) {
            char c = e.getKeyChar();
                if ( ((c < '0') || (c > '9')) && (c != KeyEvent.VK_BACK_SPACE)) {
                    e.consume();
            }
         }
        });
            
        // Assessement Panel: Downpayment
        downPaymentComboBox = new JComboBox(new Object[] {"-----","10%", "20%", "30%"});
        downPaymentComboBox.setEditable(false);
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 6; 
        AssessmentPanel.add(downPaymentComboBox, gridConstraints);

        downPaymentComboBox.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    downPaymentComboBoxActionPerformed(e);

                }
            });
        
        // Assessement Panel: Proposed Collateral
        proposedCollateralComboBox = new JComboBox(new Object[] {"-----", "Vacant Lot", "House and Lot", "Residential Condo", "Town House", "Apartment"});
        proposedCollateralComboBox.setEditable(false);
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 8; 
        AssessmentPanel.add(proposedCollateralComboBox, gridConstraints);

        proposedCollateralComboBox.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    proposedCollateralComboBoxActionPerformed(e);

                }
            });

        // Assessement Panel: Months to Pay
        monthsPayTextField.setText("");
        monthsPayTextField.setColumns(5);
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 9;    
        AssessmentPanel.add(monthsPayTextField, gridConstraints);
        
        monthsPayTextField.addKeyListener(new KeyAdapter() {
        public void keyTyped(KeyEvent e) {
            char c = e.getKeyChar();
                if ( ((c < '0') || (c > '9')) && (c != KeyEvent.VK_BACK_SPACE)) {
                    e.consume();
            }
         }
        });

        
        // Assessement Panel (BUTTONS): NAVIGATION/ FUNCTION
        // Assessement Panel: Back Button
        backButton.setText("Back");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 10;
        gridConstraints.insets = new Insets(10,10,10,10);
        AssessmentPanel.add(backButton, gridConstraints);

        backButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    backButtonActionPerformed(e);
                    nameTextField.setText("");
                    addressTextField.setText("");
                    employmentComboBox.setSelectedIndex(0);    
                    propertySPTextField.setText("");
                    downPayTextField.setText("");
                    proposedCollateralComboBox.setSelectedIndex(0); 
                    monthsPayTextField.setText("");
                    downPaymentComboBox.setSelectedIndex(0);
                    
                }
            });
        
        // Assessement Panel: Confirm Button
        confirmButton.setText("Confirm");
        gridConstraints.gridx = 2;
        gridConstraints.gridy = 10;
        gridConstraints.insets = new Insets(10,10,10,10);
        AssessmentPanel.add(confirmButton, gridConstraints);

        confirmButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e)
                {
                    confirmButtonActionPerformed(e);
                }
            });
            
        // Assessement Panel: Clear Button
        clearButton.setText("Clear");
        gridConstraints.gridx = 3;
        gridConstraints.gridy = 10;
        gridConstraints.insets = new Insets(10,10,10,10);
        AssessmentPanel.add(clearButton, gridConstraints);

        clearButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            nameTextField.setText("");
            addressTextField.setText("");
            employmentComboBox.setSelectedIndex(0);    
            propertySPTextField.setText("");
            downPayTextField.setText("");
            proposedCollateralComboBox.setSelectedIndex(0); 
            monthsPayTextField.setText("");
            downPaymentComboBox.setSelectedIndex(0);
            }
        });
        
        
        // Assessement Panel (TEXT AREA): BILLING STATEMENT
        // Assessement Panel: Home Loan Name Heading
        homeLoanNameLabel.setFont(new Font("Cambria", Font.PLAIN, 16));
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        AssessmentPanel.add(homeLoanNameLabel, gridConstraints);

        
        // Assessement Panel: Billing Heading
        gridConstraints.insets.set(10,30,10,30);
        gridConstraints.anchor = gridConstraints.SOUTH;
        billingLabel.setFont(new Font("Cambria", Font.BOLD, 25));
        billingLabel.setText("Results:");
        gridConstraints.gridx = 2;
        gridConstraints.gridy = 0;
        gridConstraints.gridwidth = 2;
        AssessmentPanel.add(billingLabel, gridConstraints);  

        gridConstraints.anchor = gridConstraints.CENTER;

        // Assessement Panel: Billing Receipt
        billTextArea.setFont(new Font("Cambria", Font.PLAIN, 14));
        billTextArea.setColumns(50);
        billTextArea.setRows(15);
        billTextArea.setEditable(false);
        gridConstraints.gridx = 2;
        gridConstraints.gridy = 0;
        gridConstraints.gridwidth = 2;
        gridConstraints.gridheight = 11;
        AssessmentPanel.add(billTextArea, gridConstraints);  

    }
    
    // Main Menu: BUTTONS - ACTION PEFORMERS
    public void vacantLotButtonActionPerformed(ActionEvent e) {
        // for Vacant Lot
        homeLoanButtonsActionPerformed(e, vacantLot);
    }

    public void houseNLotButtonActionPerformed(ActionEvent e) {
        // for House and Lot
        homeLoanButtonsActionPerformed(e, houseNLot);
    }

    public void residentialCondoButtonActionPerformed(ActionEvent e) {
        // for Residential
        homeLoanButtonsActionPerformed(e, residential);
    }

    public void townHouseButtonActionPerformed(ActionEvent e) {
        // for Town House
        homeLoanButtonsActionPerformed(e, townHouse);
    }

    public void constructionButtonActionPerformed(ActionEvent e) {
        // for Construction
        homeLoanButtonsActionPerformed(e, construction);
    }

    public void homeImprovementButtonActionPerformed(ActionEvent e) {
        // for Home Improvements
        homeLoanButtonsActionPerformed(e, homeImprovement);
    }

    public void apartmentButtonActionPerformed(ActionEvent e) {
        // for Apartments
        homeLoanButtonsActionPerformed(e, apartment);
    }

    public void homeLoanButtonsActionPerformed(ActionEvent e, Home selectedLoan) {
        this.selectedLoan = selectedLoan;
        homeLoanNameLabel.setText(selectedLoan.getName());
        setContentPane(AssessmentPanel);
        pack(); 
    }

    // Assessment Panel: BUTTONS - ACTION PERFORMERS
    public void backButtonActionPerformed(ActionEvent e) {
        setContentPane(menuPanel);
        pack();
    }

    public void confirmButtonActionPerformed(ActionEvent e) {
        updateBillTextArea();
    }
    
    // Assessment Panel: COMBO BOX - ACTION PERFORMERS
    private void downPaymentComboBoxActionPerformed(ActionEvent e) {
        //Empty
    }
    
    private void employmentComboBoxActionPerformed(ActionEvent e) {
        //Empty
    }
    
    private void proposedCollateralComboBoxActionPerformed(ActionEvent e) {
        //Empty
    }

    // Assessment Panel: Input Validation
    public void inputValidation(){
        if(this.propertySPTextField.getText().isEmpty() == true) {
            JOptionPane.showMessageDialog(null, "Error! Please Fill in the required Text Fields.", "ERROR", JOptionPane.ERROR_MESSAGE);
        } else if(this.monthsPayTextField.getText().isEmpty() == true) {
            JOptionPane.showMessageDialog(null, "Error! Please Fill in the required Text Fields.", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
    
    }
    
    // Exit Staments
    public void exitForm(WindowEvent e) {
        JFrame f;
        f = new JFrame();
        exitProgram(f);
    }

    public void exitProgram(JFrame f) {
        JOptionPane.showMessageDialog(f, "Thank you for using |APF| HOME LOAN ASSESEMENT| :D", "Program Terminating...", JOptionPane.INFORMATION_MESSAGE);
    }
    
    // Billing Area
    private void updateBillTextArea() {
        inputValidation();
        double computationPropertySP, computationMonthsPay, computationDownPayment;

        // Assessment - Information - User Get Info
        String userChoiceLoan = homeLoanNameLabel.getText(); 
        String userName = nameTextField.getText();
        String userAddress = addressTextField.getText();
        String userEmployment = employmentComboBox.getSelectedItem().toString();
        String userPropertySP = propertySPTextField.getText();//
        String userDownPayment = downPaymentComboBox.getSelectedItem().toString();
        String newuserDownPayment = downPaymentComboBox.getSelectedItem().toString().replaceAll("%","");
        String userDP = downPayTextField.getText();//
        String userProposedColl = proposedCollateralComboBox.getSelectedItem().toString();
        String userMonthsPay = monthsPayTextField.getText();//
        
        // Parsing: String - Int
        computationPropertySP = Integer.parseInt(userPropertySP);
        computationDownPayment = Integer.parseInt(newuserDownPayment);
        computationMonthsPay = Integer.parseInt(userMonthsPay);
        
        // FINAL Computation:MONTHLYINTERESETRATE, DOWNPAYMENT_PERC, COMPUTED_DOWN, AMOUNTLOAN, MONTHLYPAYMENT.
        double MONTHLYINTERESETRATE, DOWNPAYMENT_PERC, COMPUTED_DOWN, AMOUNTLOAN, MONTHLYPAYMENT;
        double totalPaymentS1, totalPaymentS2, totalPaymentS3;
        MONTHLYINTERESETRATE = .07/12;
        DOWNPAYMENT_PERC = computationDownPayment / 100; 
        COMPUTED_DOWN =  computationPropertySP * DOWNPAYMENT_PERC;
        AMOUNTLOAN = computationPropertySP - COMPUTED_DOWN;        
        MONTHLYPAYMENT = (computationPropertySP*MONTHLYINTERESETRATE) / (1-Math.pow(1+MONTHLYINTERESETRATE, - computationMonthsPay));
        
        billTextArea.setText("=========================| APF | Home Loan Assessement |========================\n\n" +
            userChoiceLoan+ "\n\n" + 

            "Name: \t\t"        +userName+ "\n" + 
            "Address: \t\t"     +userAddress+"\n" +
            "Employment: \t\t"  +userEmployment +"\n" +
            "Property Selling Price: \t₱" +computationPropertySP+ "\n" +
            "Down Payment: \t₱"          +COMPUTED_DOWN+ "\n" +
            "Amount of Financed: \t₱"          +AMOUNTLOAN+ "\n" +
            "Proposed Collateral: \t"    +userProposedColl + "\n" +
            "Months to Pay: \t\t"          +userMonthsPay + "\n\n" +
            "Monthly Payment in " + "("+userMonthsPay+") months is: ₱" + Math.round(MONTHLYPAYMENT*100)/100.0); 

    }
    
    
    public static void main(String[] args) {
        new MainFrame().show();
    }
}
