public class Home {
    private String name;
    private AssessType[] loanType;
    
    public Home(String name, AssessType[] loanType) {
        this.name = name;
        this.loanType = loanType;
        
    }
    
    public AssessType[] getRoomTypes() {
        return this.loanType;
    }
    
    public String getName() {
        return this.name;
    }
}
